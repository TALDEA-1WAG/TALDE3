package reto;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

/**
 * Bezeroa klaseak bezeroaren interfaz grafikoa irudikatzen du. Bezeroak eskuragarri dauden produktuak kontsultatu eta erosketa egin ditzake.
 * JFrame klasea oinarritzat hartzen du eta Swing osagaiekin egindako grafikoak erabiltzen ditu.
 */
public class Bezeroa extends JFrame {
    private JTextField idClienteField;
    private JTextField idProductoField;
    private JTextField cantidadField;
    private JTextArea resultArea;
    private JButton consultarProductosButton;
    private JButton realizarCompraButton;

    /**
     * Bezeroa klasearen eraikitzailea. Interfazea konfiguratzen du, leihoaren tamaina ezartzen du,
     * osagaien kokapena definitzen du eta botoien ekintza gertakariak gehitzen ditu.
     */
    public Bezeroa() {
        setTitle("Interfaz Cliente");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));

        JLabel idClienteLabel = new JLabel("ID Cliente:");
        JLabel idProductoLabel = new JLabel("ID Producto:");
        JLabel cantidadLabel = new JLabel("Cantidad:");

        idClienteField = new JTextField();
        idProductoField = new JTextField();
        cantidadField = new JTextField();

        resultArea = new JTextArea(10, 30);
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);

        consultarProductosButton = new JButton("Consultar Productos");
        realizarCompraButton = new JButton("Realizar Compra");

        panel.add(idClienteLabel);
        panel.add(idClienteField);
        panel.add(idProductoLabel);
        panel.add(idProductoField);
        panel.add(cantidadLabel);
        panel.add(cantidadField);
        panel.add(consultarProductosButton);
        panel.add(realizarCompraButton);

        add(panel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        consultarProductosButton.addActionListener(e -> consultarProductos());
        realizarCompraButton.addActionListener(e -> realizarCompra());
    }
    
    /**
     * Produktuak kontsultatzen ditu datu basean eta produktuen informazioa (ID, izena, prezioa eta stocka) 
     * emaitzen arera erakusten du.
     */

    private void consultarProductos() {
        String query = "SELECT ID_PRODUKTUA, IZENA, PREZIOA, STOCK FROM PRODUKTUAK";
        try (Connection conn = DatabaseConnection.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            resultArea.setText("Productos Disponibles:\n");
            while (rs.next()) {
                resultArea.append("ID: " + rs.getInt("ID_PRODUKTUA") + ", ");
                resultArea.append("Nombre: " + rs.getString("IZENA") + ", ");
                resultArea.append("Precio: " + rs.getDouble("PREZIOA") + ", ");
                resultArea.append("Stock: " + rs.getInt("STOCK") + "\n");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al consultar productos: " + ex.getMessage());
        }
    }
    
    /**
     * Erosketa bat egiten du, stockaren existentzia egiaztatzen du eta guztira kalkulatzen du.
     * Erosketa arrakastatsua bada, salmenta datu basean erregistratzen du.
     */

    private void realizarCompra() {
        try (Connection conn = DatabaseConnection.connect()) {
            int idCliente = Integer.parseInt(idClienteField.getText());
            int idProducto = Integer.parseInt(idProductoField.getText());
            int cantidad = Integer.parseInt(cantidadField.getText());

            String productoQuery = "SELECT STOCK, PREZIOA FROM PRODUKTUAK WHERE ID_PRODUKTUA = ?";
            try (PreparedStatement stmt = conn.prepareStatement(productoQuery)) {
                stmt.setInt(1, idProducto);
                ResultSet rsProducto = stmt.executeQuery();

                if (!rsProducto.next()) {
                    JOptionPane.showMessageDialog(this, "Producto no encontrado.");
                    return;
                }
                int stockDisponible = rsProducto.getInt("STOCK");
                if (cantidad > stockDisponible) {
                    JOptionPane.showMessageDialog(this, "No hay suficiente stock.");
                    return;
                }

                double total = cantidad * rsProducto.getDouble("PREZIOA");
                String ventaQuery = "INSERT INTO SALMENTAK (ID_BEZERO, DATA, ID_PRODUKTUA) VALUES (?, CURRENT_TIMESTAMP, ?)";
                try (PreparedStatement stmtVenta = conn.prepareStatement(ventaQuery, Statement.RETURN_GENERATED_KEYS)) {
                    stmtVenta.setInt(1, idCliente);
                    stmtVenta.setInt(2, idProducto);
                    int affectedRows = stmtVenta.executeUpdate();
                    if (affectedRows > 0) {
                        JOptionPane.showMessageDialog(this, "Compra realizada. Total: " + total);
                    } else {
                        JOptionPane.showMessageDialog(this, "Error al registrar la venta.");
                    }
                }
            }
        } catch (SQLException | NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Error en la compra: " + ex.getMessage());
        }
    }

    /**
     * Aplikazioa hasteko metodoa. Bezeroa klasearen instantzioa sortzen du eta ikusgai jartzen du.
     */

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Bezeroa().setVisible(true));
    }
}
