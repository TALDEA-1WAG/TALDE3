package reto;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

/**
 * InicioSesion klaseak erabiltzailearen saioaren hasiera kudeatzen du.
 * Erabiltzaileak izenak eta pasahitzak sartzen ditu, eta hauek egiaztatzean, hasierako saioa egin edo errore bat agertzen da.
 */
public class InicioSesion extends JFrame {
    
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JLabel messageLabel;

    /**
     * InicioSesion klasearen eraikitzailea. Interfazea konfiguratzen du, osagaiak gehitzen ditu eta
     * login botoiari ekintza bat gehitzen dio.
     */
    public InicioSesion() {
        // Interfazea konfiguratu
        setTitle("Saioaren Hasiera");
        setSize(300, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new FlowLayout());

        usernameField = new JTextField(15);
        passwordField = new JPasswordField(15);
        loginButton = new JButton("Saioa hasi");
        messageLabel = new JLabel("");

        add(new JLabel("Erabiltzailea:"));
        add(usernameField);
        add(new JLabel("Pasahitza:"));
        add(passwordField);
        add(loginButton);
        add(messageLabel);

        // Login botoiaren ekintza
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText().trim(); // Espazio gehigarriak ezabatzea
                String password = new String(passwordField.getPassword()).trim();

                // Kredentzialak egiaztatu
                if (verificarCredenciales(username, password)) {
                    messageLabel.setText("Saioa hasi da!");
                } else {
                    messageLabel.setText("Kredentzial okerrak.");
                }
            }
        });
    }

    /**
     * Erabiltzailearen izena eta pasahitza egiaztatzen ditu datu basean.
     * 
     * @param username Erabiltzailearen izena
     * @param password Erabiltzailearen pasahitza
     * @return true, saioa hasi bada; false, bestela
     */
    private boolean verificarCredenciales(String username, String password) {
        try (Connection conn = DatabaseConnection.connect()) {
            String query = "SELECT * FROM ERABILTZAILEAK WHERE IZENA = ? AND PASAHITZA = ?";

            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, username);  // Erabiltzaile izena ezarri
                stmt.setString(2, password);  // Pasahitza ezarri 

                ResultSet rs = stmt.executeQuery();

                // Kredentzialen egiaztapena
                if (rs.next()) {
                    String mota = rs.getString("MOTA").trim();  // Erabiltzailearen motaren informazioa
                    System.out.println("Mota balioa: " + mota);  // Depurazioa: "mota" balioa ikusteko
                    
                    // Erabiltzailearen rolaren arabera leiho egokia ireki
                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
                        public void run() {
                            // Saioaren hasiera leihoa itxi
                            dispose();  // Hasierako saioaren leihoa itxi

                            // Erabiltzailearen rolaren arabera leiho egokia ireki
                            abrirVentanaSegunRol(mota);  // Rolaren arabera leihoa irekiko du
                        }
                    });
                    return true;  // Saioa hasi da
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // Kredentzialak okerrak badira
    }

    /**
     * Erabiltzailearen rolaren arabera leiho egokia irekitzen du.
     * 
     * @param mota Erabiltzailearen mota (rol)
     */
    private void abrirVentanaSegunRol(String mota) {
        if ("SALTZAILE".equals(mota)) {
            new Saltzaile().setVisible(true);
        } else if ("BEZERO".equals(mota)) {
            new Bezeroa().setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Erabiltzailearen rolak ez du onarpenik.");
        }
    }

    /**
     * Aplikazioa hasteko metodoa. InicioSesion klasearen instantzia sortzen du eta ikusgai jartzen du.
     */
    public static void main(String[] args) {
        // Erabiltzailearen interfazea sortu eta erakutsi
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new InicioSesion().setVisible(true);
            }
        });
    }
}
