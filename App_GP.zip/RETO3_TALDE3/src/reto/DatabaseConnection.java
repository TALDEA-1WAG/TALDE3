package reto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * DatabaseConnection klaseak datu basearekin konektatzeko funtzionalitatea eskaintzen du.
 * JDBC (Java Database Connectivity) erabiltzen du konekzioa ezartzeko.
 */
public class DatabaseConnection {
    
    // Datu basearen URL, erabiltzailearen izena eta pasahitza definitzen dira.
    private static final String URL = "jdbc:oracle:thin:@localhost:1521/XEPDB1"; // Aldatu URL-a eta datu basea
    private static final String USER = "ERRONKA"; // Aldatu erabiltzaile izena
    private static final String PASSWORD = "ikasle"; // Aldatu pasahitza

    /**
     * Datu basearekin konektatzen da.
     * 
     * @return Konektatutako Connection objektua
     * @throws SQLException Konektatzeko errorea gertatzen bada
     */
    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
