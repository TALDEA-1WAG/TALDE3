package reto;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;


/**
 * Saltzaile klaseak saltzaile baten interfazea kudeatzen du.
 * Produktuak gehitzeko, ezabatzeko, editatzeko, salmentak egiteko eta salmentak kontsultatzeko aukera ematen du.
 */

public class Saltzaile extends JFrame {

    private JButton agregarProductoButton;
    private JButton eliminarProductoButton;
    private JButton editarProductoButton;
    private JButton realizarVentaButton;
    private JButton consultarVentasButton;
    private JTextArea resultArea;
    
    /**
     * Eraikitzaileak interfazea sortzen eta botoien ekintzak ezartzen ditu.
     */

    public Saltzaile() {
        setTitle("Interfaz del Vendedor");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Panel y Layout
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());

        // Crear los botones
        agregarProductoButton = new JButton("Agregar Producto");
        eliminarProductoButton = new JButton("Eliminar Producto");
        editarProductoButton = new JButton("Editar Producto");
        realizarVentaButton = new JButton("Realizar Venta");
        consultarVentasButton = new JButton("Consultar Ventas");

        // Crear el área de texto para mostrar resultados
        resultArea = new JTextArea(10, 50);
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);

        // Agregar botones al panel
        panel.add(agregarProductoButton);
        panel.add(eliminarProductoButton);
        panel.add(editarProductoButton);
        panel.add(realizarVentaButton);
        panel.add(consultarVentasButton);

        // Agregar el panel al JFrame
        add(panel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        // Agregar listeners a los botones
        agregarProductoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarProducto();
            }
        });

        eliminarProductoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarProducto();
            }
        });

        editarProductoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editarProducto();
            }
        });

        realizarVentaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                realizarVenta();
            }
        });

        consultarVentasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                consultarVentas();
            }
        });
    }
    
    /**
     * Produktu berri bat gehitzen du datu basera.
     */

    // Agregar un producto a la base de datos
    private void agregarProducto() {
        String nombre = JOptionPane.showInputDialog(this, "Ingrese el nombre del producto:");
        String precioStr = JOptionPane.showInputDialog(this, "Ingrese el precio del producto:");
        String stockStr = JOptionPane.showInputDialog(this, "Ingrese la cantidad disponible:");
        String ubicacion = JOptionPane.showInputDialog(this, "Ingrese la ubicación del producto:");

        if (nombre != null && precioStr != null && stockStr != null && ubicacion != null) {
            try {
                double precio = Double.parseDouble(precioStr);
                int stock = Integer.parseInt(stockStr);

                // Insertar el producto con un ID autogenerado por la secuencia
                String query = "INSERT INTO PRODUKTUAK (ID_PRODUKTUA, IZENA, PREZIOA, STOCK, KOKAPENA) VALUES (produktuak_seq.NEXTVAL, ?, ?, ?, ?)";
                
                try (Connection conn = DatabaseConnection.connect();
                     PreparedStatement stmt = conn.prepareStatement(query)) {

                    stmt.setString(1, nombre);
                    stmt.setDouble(2, precio);
                    stmt.setInt(3, stock);
                    stmt.setString(4, ubicacion);
                    stmt.executeUpdate();

                    JOptionPane.showMessageDialog(this, "Producto agregado correctamente.");
                }

            } catch (SQLException | NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Error al agregar el producto: " + ex.getMessage());
            }
        }
    }

    /**
     * Produktu bat ezabatzen du IDaren arabera.
     */
    // Eliminar un producto de la base de datos
    private void eliminarProducto() {
        String idStr = JOptionPane.showInputDialog(this, "Ingrese el ID del producto a eliminar:");

        if (idStr != null) {
            try {
                int id = Integer.parseInt(idStr);

                String query = "DELETE FROM PRODUKTUAK WHERE ID_PRODUKTUA = ?";
                try (Connection conn = DatabaseConnection.connect();
                     PreparedStatement stmt = conn.prepareStatement(query)) {

                    stmt.setInt(1, id);
                    int rowsAffected = stmt.executeUpdate();

                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(this, "Producto eliminado correctamente.");
                    } else {
                        JOptionPane.showMessageDialog(this, "No se encontró el producto con ID: " + id);
                    }
                }

            } catch (SQLException | NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Error al eliminar el producto: " + ex.getMessage());
            }
        }
    }
    
    /**
     * Produktu baten informazioa editatzen du IDaren arabera.
     */

    // Editar un producto de la base de datos
    private void editarProducto() {
        String idStr = JOptionPane.showInputDialog(this, "Ingrese el ID del producto a editar:");

        if (idStr != null) {
            try {
                int id = Integer.parseInt(idStr);

                String query = "SELECT * FROM PRODUKTUAK WHERE ID_PRODUKTUA = ?";
                try (Connection conn = DatabaseConnection.connect();
                     PreparedStatement stmt = conn.prepareStatement(query)) {

                    stmt.setInt(1, id);
                    ResultSet rs = stmt.executeQuery();

                    if (rs.next()) {
                        String nombre = JOptionPane.showInputDialog(this, "Nuevo nombre del producto:", rs.getString("IZENA"));
                        String precioStr = JOptionPane.showInputDialog(this, "Nuevo precio del producto:", rs.getDouble("PREZIOA"));
                        String stockStr = JOptionPane.showInputDialog(this, "Nueva cantidad disponible:", rs.getInt("STOCK"));
                        String ubicacion = JOptionPane.showInputDialog(this, "Nueva ubicación del producto:", rs.getString("KOKAPENA"));

                        if (nombre != null && precioStr != null && stockStr != null && ubicacion != null) {
                            double precio = Double.parseDouble(precioStr);
                            int stock = Integer.parseInt(stockStr);

                            String updateQuery = "UPDATE PRODUKTUAK SET IZENA = ?, PREZIOA = ?, STOCK = ?, KOKAPENA = ? WHERE ID_PRODUKTUA = ?";
                            try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {
                                updateStmt.setString(1, nombre);
                                updateStmt.setDouble(2, precio);
                                updateStmt.setInt(3, stock);
                                updateStmt.setString(4, ubicacion);
                                updateStmt.setInt(5, id);
                                updateStmt.executeUpdate();

                                JOptionPane.showMessageDialog(this, "Producto editado correctamente.");
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "No se encontró el producto con ID: " + id);
                    }

                }

            } catch (SQLException | NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Error al editar el producto: " + ex.getMessage());
            }
        }
    }

    /**
     * Salmenta bat egiten du eta datu basean gordetzen du.
     */
    
    // Realizar una venta y registrar en la base de datos
    private void realizarVenta() {
        String idProductoStr = JOptionPane.showInputDialog(this, "Ingrese el ID del producto a vender:");
        String cantidadStr = JOptionPane.showInputDialog(this, "Ingrese la cantidad a vender:");
        String idVendedorStr = JOptionPane.showInputDialog(this, "Ingrese su ID de Vendedor:");
        String idClienteStr = JOptionPane.showInputDialog(this, "Ingrese el ID del cliente:");

        if (idProductoStr != null && cantidadStr != null && idVendedorStr != null && idClienteStr != null) {
            try {
                // Validar que los valores ingresados sean números válidos
                int idProducto = Integer.parseInt(idProductoStr);
                int cantidad = Integer.parseInt(cantidadStr);
                int idVendedor = Integer.parseInt(idVendedorStr);
                int idCliente = Integer.parseInt(idClienteStr);

                String query = "SELECT * FROM PRODUKTUAK WHERE ID_PRODUKTUA = ?";
                try (Connection conn = DatabaseConnection.connect();
                     PreparedStatement stmt = conn.prepareStatement(query)) {

                    stmt.setInt(1, idProducto);
                    ResultSet rs = stmt.executeQuery();

                    if (rs.next()) {
                        int stock = rs.getInt("STOCK");
                        if (cantidad <= stock) {
                        	String ventaQuery = "INSERT INTO SALMENTAK (ID_SALMENTA, ID_SALTZAILE, ID_BEZERO, DATA) VALUES (salmenta_seq.NEXTVAL, ?, ?, CURRENT_TIMESTAMP)";
                            try (PreparedStatement ventaStmt = conn.prepareStatement(ventaQuery)) {
                                ventaStmt.setInt(1, idVendedor);
                                ventaStmt.setInt(2, idCliente);
                                ventaStmt.executeUpdate();

                                // Actualizar el stock del producto
                                String updateQuery = "UPDATE PRODUKTUAK SET STOCK = STOCK - ? WHERE ID_PRODUKTUA = ?";
                                try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {
                                    updateStmt.setInt(1, cantidad);
                                    updateStmt.setInt(2, idProducto);
                                    updateStmt.executeUpdate();
                                }

                                JOptionPane.showMessageDialog(this, "Venta registrada correctamente.");
                            }
                        } else {
                            JOptionPane.showMessageDialog(this, "No hay suficiente stock para esta venta.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Producto no encontrado.");
                    }

                }

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Error al ingresar datos. Asegúrese de que todos los campos sean números enteros: " + ex.getMessage());
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error al realizar la venta: " + ex.getMessage());
            }
        }
    }
    
    /**
     * Egindako salmenta guztiak bistaratzen ditu.
     */

    // Consultar todas las ventas realizadas
    private void consultarVentas() {
        String query = "SELECT * FROM SALMENTAK";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            resultArea.setText("Ventas Realizadas:\n");
            while (rs.next()) {
                resultArea.append("ID Venta: " + rs.getInt("ID_SALMENTA") +
                        ", Vendedor ID: " + rs.getInt("ID_SALTZAILE") +
                        ", Cliente ID: " + rs.getInt("ID_BEZERO") +
                        ", Fecha: " + rs.getTimestamp("DATA") + "\n");
                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al consultar las ventas: " + ex.getMessage());
        }
    }
}
